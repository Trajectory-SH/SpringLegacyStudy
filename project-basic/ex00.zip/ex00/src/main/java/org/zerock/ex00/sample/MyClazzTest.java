package org.zerock.ex00.sample;

public class MyClazzTest {
    public static void main(String[] args) {
        System.out.println("hello world");
    }
}
