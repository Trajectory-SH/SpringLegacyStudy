package org.zerock.ex00.sample;

public class TestClass {

    public static void main(String[] args) {

        System.out.println("helloWorld");
    }
}
