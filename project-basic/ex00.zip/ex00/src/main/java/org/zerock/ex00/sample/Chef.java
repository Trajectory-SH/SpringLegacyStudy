package org.zerock.ex00.sample;

import lombok.ToString;
import org.springframework.stereotype.Component;

@ToString
@Component
public class Chef {

}
