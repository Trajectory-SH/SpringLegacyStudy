package org.zerok.ex00;

public class LoadTest {
}
